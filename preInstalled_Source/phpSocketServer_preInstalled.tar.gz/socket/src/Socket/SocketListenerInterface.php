<?php

namespace Dazzle\Socket;

use Dazzle\Event\EventEmitterInterface;
use Dazzle\Loop\LoopResourceInterface;
use Dazzle\Stream\StreamDataInterface;

/**
 * @event connect : callable(object, SocketInterface)
 */
interface SocketListenerInterface extends EventEmitterInterface, LoopResourceInterface, StreamDataInterface
{
    /**
     * Star listener and underlying resource object.
     *
     * @return void
     */
    public function start();

    /**
     * Stop listener and underlying resource object. It is an alias for close() method.
     *
     * @see StreamDataInterface::close
     */
    public function stop();

    /**
     * Get listener endpoint.
     *
     * This method returns server endpoint with this pattern [$protocol://$address:$port].
     *
     * @return string
     */
    public function getLocalEndpoint();

    /**
     * Get socket local address.
     *
     * @return string
     */
    public function getLocalAddress();

    /**
     * Get socket local host.
     *
     * @return string
     */
    public function getLocalHost();

    /**
     * Get socket local port.
     *
     * @return string
     */
    public function getLocalPort();

    /**
     * Get socket local protocol.
     *
     * @return string
     */
    public function getLocalProtocol();

    /**
     * Return bool indicating whether the listener is encrypted.
     *
     * @return bool
     */
    public function isEncrypted();
}
