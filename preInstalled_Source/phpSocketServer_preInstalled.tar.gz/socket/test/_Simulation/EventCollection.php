<?php

namespace Dazzle\Socket\Test\_Simulation;

use SplQueue;

class EventCollection extends SplQueue
{}
