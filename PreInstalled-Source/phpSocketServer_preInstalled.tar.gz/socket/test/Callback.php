<?php

namespace Dazzle\Socket\Test;

class Callback
{
    public function __invoke()
    {}
}